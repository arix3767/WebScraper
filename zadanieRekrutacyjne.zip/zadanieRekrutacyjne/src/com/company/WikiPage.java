package com.company;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WikiPage {

    private String url;
    private String title;
    private String content;

    public WikiPage(String url, String title, String content) {
        this.url = url;
        this.title = title;
        this.content = content;
    }

    public static String getTitle(ChromeDriver driver) {
        return driver.getTitle();
    }

    public static String getHistoryData(ChromeDriver driver) {
        String data = "";
        WebElement historyContent = driver.findElement(By.id("content"));
        data = historyContent.getText();
        data = data.substring(data.indexOf("History[edit]"), data.lastIndexOf("Components[edit]"));
        return data;
    }

    public static String getPictureUrl(ChromeDriver driver) {
        return driver.findElement(By.xpath("//*[@id=\"mw-content-text\"]/div[1]/table[2]/tbody/tr[1]/td/a/img")).getAttribute("src");
    }
}
